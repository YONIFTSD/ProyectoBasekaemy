@extends('layouts.dashboard')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="ms-panel">
            <div class="ms-panel-header">
                <h6>Dashboard</h6>
            </div>
            <div class="ms-panel-body p-0">
            </div>
        </div>
    </div>
</div>
@endsection